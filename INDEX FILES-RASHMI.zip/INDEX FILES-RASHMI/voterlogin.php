<?php 
if(isset($_POST['submit'])){
    $conn=mysqli_connect('localhost','root','','users');
    
    if(!$conn ){
        echo "not connected";
    }
    
    echo $username = mysqli_real_escape_string($conn,$_POST['name']);
    echo $password = mysqli_real_escape_string($conn,$_POST['password']);
     $email = mysqli_real_escape_string($conn,$_POST['email']);
	
    
    $query="INSERT INTO voter(user_name,Password) VALUES('$username','$password')";
    $result=mysqli_query($conn,$query);
    
    $result=mysqli_query($conn,$query);
    
    $var = "Thank you for your vote..";
    echo "<h1 style='color:white'>" . $var . "</h1>";
    
    
    
    if(!$result){
        die("FAILED".mysqli_error($conn));
    }
}
    ?>

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>SC Election</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>
    
                       
 <style>                   


.dropdown {
    position: relative;
    display: inline-block;
}

.login-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.login-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown a:hover {background-color: #f1f1f1;}

.show {display: block;}
</style>


</head>


<body id="top">
    
    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-jump">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>


    <!-- header
    ================================================== -->
   <header class="s-header">

        <div class="row">

            <div class="header-logo">
            </div>
            
            <nav class="header-nav-wrap">
                 <ul class="header-nav">
                
                    <li class="current"><a href="Mainpage.php">Home</a></li>
                    <li> <a  onclick="myFunction()" class="smoothscroll" class="header-nav"  href="" title="Login">Login</a></li>
                  
                    <li><a href="count_vote.php">admin</a></li>
 
<body>

<div class="dropdown">

  <div id="myDropdown" class="login-content">           
           
      <a href="Registerlogin.php">Register</a>
    <a href="Contestantlogin.php">Contestant</a>
    <a href="voterlogin.php">Voter</a>
  </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("login-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

 
                    
                    
                    
                    
                    <h2></h2>
                    <p><a href="file:///C:/xampp/htdocs/xampp/IP-Project-master/SC%20Election/IP-Project-v1.02-master/login1/Login-v1-master/Login_v18/index1.html?email=abelsimon30%40gmail.com&pass=asasdsad"></a></p>

</body>
</html>

                </ul>
            </nav> <!-- end header-nav-wrap -->
            
            <a class="header-menu-toggle" href="#0">
                <span class="header-menu-icon"></span>
            </a>

        </div> <!-- end row -->

    </header> <!-- end s-header -->


    <!-- home
    ================================================== -->
    <section id="home" class="s-home page-hero target-section" data-parallax="scroll" data-image-src="images/hero-bg.jpg" data-natural-width=3000 data-natural-height=2000 data-position-y=center>

        <div class="shadow-overlay"></div>

        <div class="home-content">

            <div class="row home-content__main">

                <h1>
                Welcome to the <br>
                Student Council  <br>
                Elections
                </h1>

              
            </div>
        </div>  <!-- end home-content__main -->

      
    </section> <!-- end s-home -->


    
 <!-- Java Script
    ================================================== -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <section id="about" class="s-about target-section">

        <div class="row section-header" data-aos="fade-up">
            <div class="col-full">


<?php
// define variables and set to empty values

/*$name =$comment = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
} */
?> 

<link rel="stylesheet"
href="https: //maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

                
<h2>&emsp;&emsp;&emsp;&emsp;Welcome!</h2>
<p>
<form method="post" action="voting.php">
    
  Name: &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type="varchar" name="name" required>
    <span class="error">* <?php// echo $nameErr;?></span>

    <br>
    
    Email:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type="email" name="email" required>
    <span class="error">* <?php //echo $passwordErr;?></span>
    <br>
    
Password:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type="password" name="password" required>
    <span class="error">* <?php //echo $passwordErr;?></span>
    <br>
    

    
 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 
    <input type="submit" name="submit" value="Submit">  


<form action="Mainpage.php" method="post"> <button type="submit">CANCEL</button>
</form>
    
    
</form>

   </div>
        </div>
 
    
