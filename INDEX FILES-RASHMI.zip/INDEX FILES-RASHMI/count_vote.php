<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$query = "SELECT * FROM `contestant` where `Position` = 'GS'";
$result = mysqli_query($conn,$query);
$gs = array();
while($row = mysqli_fetch_array($result)){
	$gs_name = array($row['Name']);
	$gs = array_merge($gs,$gs_name);
}
print_r($gs);
$gs_count = mysqli_num_rows($result);
$gs_vote = array();
for($i = 0;$i < $gs_count; $i++){
	
	$query = "select * from voter where `GS` = '".$gs[$i]."';";
	$result = mysqli_query($conn,$query);
	if(!$result){
		die("something went wrong ".mysqli_error($conn));
	}
	$count = array(mysqli_num_rows($result));
	$gs_vote = array_merge($gs_vote,$count);
}
print_r($gs_vote);

echo "<br>";

$query = "SELECT * FROM `contestant` where `Position` = 'CS'";
$result = mysqli_query($conn,$query);
$cs = array();
while($row = mysqli_fetch_array($result)){
	$cs_name = array($row['Name']);
	$cs = array_merge($cs,$cs_name);
}
print_r($cs);
$cs_count = mysqli_num_rows($result);
$cs_vote = array();
for($i = 0;$i < $cs_count; $i++){
	
	$query = "select * from voter where `CS` = '".$cs[$i]."';";
	$result = mysqli_query($conn,$query);
	if(!$result){
		die("something went wrong ".mysqli_error($conn));
	}
	$count = array(mysqli_num_rows($result));
	$cs_vote = array_merge($cs_vote,$count);
}
print_r($cs_vote);

echo "<br>";


$query = "SELECT * FROM `contestant` where `Position` = 'SS'";
$result = mysqli_query($conn,$query);
$ss = array();
while($row = mysqli_fetch_array($result)){
	$ss_name = array($row['Name']);
	$ss = array_merge($ss,$ss_name);
}
print_r($ss);
$ss_count = mysqli_num_rows($result);
$ss_vote = array();
for($i = 0;$i < $ss_count; $i++){
	
	$query = "select * from voter where `SS` = '".$ss[$i]."';";
	$result = mysqli_query($conn,$query);
	if(!$result){
		die("something went wrong ".mysqli_error($conn));
	}
	$count = array(mysqli_num_rows($result));
	$ss_vote = array_merge($ss_vote,$count);
}
print_r($ss_vote);
echo "<br>";


$query = "SELECT * FROM `contestant` where `Position` = 'LR'";
$result = mysqli_query($conn,$query);
$lr = array();
while($row = mysqli_fetch_array($result)){
	$lr_name = array($row['Name']);
	$lr = array_merge($lr,$lr_name);
}
print_r($lr);
$lr_count = mysqli_num_rows($result);
$lr_vote = array();
for($i = 0;$i < $lr_count; $i++){
	
	$query = "select * from voter where `LR` = '".$lr[$i]."';";
	$result = mysqli_query($conn,$query);
	if(!$result){
		die("something went wrong ".mysqli_error($conn));
	}
	$count = array(mysqli_num_rows($result));
	$lr_vote = array_merge($lr_vote,$count);
}
print_r($lr_vote);
echo "<br>";

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Count</title>
    
    
</head>
<body>
	
</body>
</html>