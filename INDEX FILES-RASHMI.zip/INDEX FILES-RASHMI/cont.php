<?php

include("db_conn.php");
include("function.php");

if(isset($_POST['submit'])){
    
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $password = mysqli_real_escape_string($conn,$_POST['Password']);
    $position = mysqli_real_escape_string($conn,$_POST['Position']);
    $comment = mysqli_real_escape_string($conn,$_POST['Comment']);
$username = string_check($username);
$password = string_check($password);
$position = string_check($position);
$comment = string_check($comment);    
//echo $password;
    
    $login_query = "SELECT * from `contestant` where `user_name` = '$username';";
    $login_result =mysqli_query($conn, $login_query);
    query_check($login_result);

       while($row = mysqli_fetch_array($login_result)){
            
			$stud_username=$row['name'];
           $stud_password = $row['Password'];
           $stud_position = $row['Position'];
           $stud_comment = $row['Comment']
       	
     }
   // echo $stud_password;

    $password = crypt($password,$stud_password);
	$password = substr($password,0,90);
	echo $password;
     if($password !== $stud_password && $username !== $stud_username){
       header("Location:Contestantlogin.html");
    
        echo "<script type='text/javascript'>alert('Invalid username and password')</script>";
    }
    
    
  else   if($password == $stud_password && $username == $stud_username){
            //echo"<br> password";
            
        echo "<script type='text/javascript'>alert('successful')</script>";

           //header("Location: vote_candidates.php");
		}
    
    
    else{
            echo "<script type='text/javascript'>alert('Invalid username or password')</script>";
			
        }

}
    


?>