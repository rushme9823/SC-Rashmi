<?php

include("db_conn.php");
include("function.php");

if(isset($_POST['submit'])){
    
    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);

$username = string_check($username);
$password = string_check($password);
//echo $password;
    
    $login_query = "SELECT * from `voter` where `user_name` = '$username';";
    $login_result =mysqli_query($conn, $login_query);
    query_check($login_result);

       while($row = mysqli_fetch_array($login_result)){
            
			$stud_username=$row['user_name'];
           $stud_password = $row['Password'];
       	
     }
   // echo $stud_password;

    $password = crypt($password,$stud_password);
	$password = substr($password,0,90);
	echo $password;
     if($password !== $stud_password && $username !== $stud_username){
       header("Location:newvoterlogin.php");
    
        echo "<script type='text/javascript'>alert('Invalid username and password')</script>";
    }
    
    
  else   if($password == $stud_password && $username == $stud_username){
            //echo"<br> password";
            
        echo "<script type='text/javascript'>alert('successful')</script>";

           //header("Location: vote_candidates.php");
		}
    
    
    else{
            echo "<script type='text/javascript'>alert('Invalid username or password')</script>";
			
        }

}
    


?>