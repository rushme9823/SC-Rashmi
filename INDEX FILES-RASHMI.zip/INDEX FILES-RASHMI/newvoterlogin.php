<?php include("login_entry.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <style>
    
    body {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
  background: url(https://picsum.photos/3000/2000/?image=1015);
  background-size: cover;
  background-repeat: no-repeat;
}

body::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 25%;
  height: 100%;
  background-color: #03a9f4;
  opacity: 0.8;
}

.form {
  position: absolute;
  top: 50%;
  left: 25%;
  transform: translate(-50%, -50%);
  width: 350px;
  min-height: 400px;
  background-color: #fff;
  box-shadow: 0 15px 50px rgba(0, 0, 0, 0.5);
  padding: 50px;
  box-sizing: border-box;
}

.form h2 {
  color: #777;
  margin: 0 0 40px;
  padding: 0;
}

.form .input-box {
  position: relative;
  margin: 20px 0;
}

.form .input-box input {
  width: 100%;
  font-size: 16px;
  border: none;
  border-bottom: 2px solid #777;
  outline: none;
  padding: 10px;
  padding-left: 30px;
  box-sizing: border-box;
  font-weight: bold;
  color: #777;
}

.form .input-box input:focus,
.form .input-box input:valid {
  border-bottom-color: #03a9f4;
}

.form .input-box .fa {
  position: absolute;
  top: 8px;
  left: 5px;
  font-size: 18px;
  color: #777;
}

.form .input-box input[type="submit"] {
  border: none;
  cursor: pointer;
  background-color: #03a9f4;
  color: #fff;
  font-weight: bold;
  transition: 0.5s;
}

.form .input-box input[type="submit"]:hover {
  background-color: #ff4987;
}

.form a {
  text-decoration: none;
  color: #777;
  margin-top: 20px;
  font-weight: bold;
  display: inline-block;
  transition: 0.5s;
}

.form a:hover {
  color: #ff4987;
}
    </style>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>
<body>
    
<div class="form">
  <form action="" method="post">
    <h2>Sign In</h2>
    <div class="input-box">
      <i class="fa fa-user" aria-hidden="true"></i>
      <input type="text" name="username" placeholder="Username" required>
    </div>
    <div class="input-box">
      <i class="fa fa-unlock-alt" aria-hidden="true"></i>
      <input type="password" name="password" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
    </div>
    <div class="input-box">
      <input type="submit" name="login" id="login" value="Login">
    </div>
    <a href="#">Forget Password</a>
  </form>
</div>
    

</body>
</html>    


