<?php 
if(isset($_POST['submit'])){
    $conn=mysqli_connect('localhost','root','','users');
    
    if(!$conn ){
        echo "not connected";
    }
    
    
    echo $username = mysqli_real_escape_string($conn,$_POST['name']);
    echo $password = mysqli_real_escape_string($conn,$_POST['password']);
    echo $cnf_password = mysqli_real_escape_string($conn,$_POST['cnf_password']);
    
    echo $email =mysqli_real_escape_string($conn,$_POST['email']);
    echo $branch =mysqli_real_escape_string($conn,$_POST['branch']);
    echo $rollno =mysqli_real_escape_string($conn,$_POST['rollno']);
    echo $gender =mysqli_real_escape_string($conn,$_POST['gender']);
    
  /*  echo $comment = mysqli_real_escape_string($conn,$_POST['comment']);*/
    
    $query="INSERT INTO `registration` (`id`, `Name`, `Password`, `Confirm_pass`, `Email`, `Branch`, `Roll_no`, `Gender`) VALUES (NULL, '$username ', '$password', '$cnf_password', '$email', '$branch', '$rollno', '$gender');";
    
    $result=mysqli_query($conn,$query);
    
    $var = "Registered Succesfully!!";
    echo "<h1 style='color:white'>" . $var . "</h1>";
    
    if(!$result){
        die("FAILED".mysqli_error($conn));
    }
    
}
?>


<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>SC Election</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>

</head>


<body id="top">
    
    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-jump">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>


    <!-- header
    ================================================== -->
    <header class="s-header">

        <div class="row">

            <div class="header-logo">
            </div>
            
            <nav class="header-nav-wrap">
                <ul class="header-nav">
                    <li class="current"><a href="Mainpage.php">Home</a></li>
                    <li> <a  onclick="myFunction()" class="smoothscroll" class="header-nav"  href="" title="Login">Login</a></li>
                  
                    <li><a href="count_vote.php">admin</a></li>
                    
                    
 <style>                   


.dropdown {
    position: relative;
    display: inline-block;
}

.login-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.login-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown a:hover {background-color: #f1f1f1;}

.show {display: block;}
</style>

<body>

<div class="dropdown">

  <div id="myDropdown" class="login-content">           
           
      <a href="Registerlogin.php">Register</a>
    <a href="Contestantlogin.php">Contestant</a>
    <a href="voterlogin.php">Voter</a>
  </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("login-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

 
                    
                    
                    
                    <h2></h2>
                    <p><a href="file:///C:/xampp/htdocs/xampp/IP-Project-master/SC%20Election/IP-Project-v1.02-master/login1/Login-v1-master/Login_v18/index1.html?email=abelsimon30%40gmail.com&pass=asasdsad"></a></p>

</body>


                </ul>
            </nav> <!-- end header-nav-wrap -->
            
            <a class="header-menu-toggle" href="#0">
                <span class="header-menu-icon"></span>
            </a>

        </div> <!-- end row -->

    </header> <!-- end s-header -->


    <!-- home
    ================================================== -->
    <section id="home" class="s-home page-hero target-section" data-parallax="scroll" data-image-src="images/hero-bg.jpg" data-natural-width=3000 data-natural-height=2000 data-position-y=center>

        <div class="shadow-overlay"></div>

        <div class="home-content">

            <div class="row home-content__main">

                <h1>
                Welcome to the <br>
                Student Council  <br>
                Elections
                </h1>

                

      
    </section> <!-- end s-home -->


    
 <!-- Java Script
    ================================================== -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <section id="about" class="s-about target-section">

        <div class="row section-header" data-aos="fade-up">
            <div class="col-full">

<link rel="stylesheet"
href="https: //maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

    
<h2>Registration</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="Registerlogin.php">
    
  Name:  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type="text" name="name">
<span class="error">*</span>
    <br>
    
    Password:&ensp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type="password" name="password">
<span class="error">* <?php  //$passwordErr;?></span>
    <br>
    
     Confirm Password:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    <input type="text" name="cnf_password">
<span class="error">* <?php // $passwordErr;?></span>
    <br>
    
    Email:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;
    <input type="email" name="email">
  <span class="error">* <?php  //$emailErr;?></span>
  <br>
    
 
    
    
     Branch:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
    
  <input type="radio" name="branch" value="computer">Computer &emsp;
  <input type="radio" name="branch" value="extc">EXTC &emsp;
  <input type="radio" name="branch" value="mechnical">Mechnical &emsp;
    <input type="radio" name="branch" value="electrical">Electrical &emsp;
  <input type="radio" name="branch" value="information">Information technology &emsp;
     <br>
       
   Roll number: &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<input type="int" name="rollno">
    <span class="error">* <?php  //$rollnoErr;?></span>
  <br>
  Gender: 
&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
  
  <input type="radio" name="gender" value="female">Female &emsp;
  <input type="radio" name="gender" value="male">Male &emsp;
  <input type="radio" name="gender" value="other">Other 
  <span class="error">* <?php // $genderErr;?></span>
    <br><br>
  <input type="submit" name="submit" value="Submit">  
    <form action="Mainpage.php" method="post"> <button type="submit">CANCEL</button>
</form>
</form>

   </div>
        </div>
        </body>
        </html>