<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>
<?php 
	if(isset($_POST['submit'])){
		$gs_vote = $_POST['GS'];
		$cs_vote = $_POST['CS'];
		$ss_vote = $_POST['SS'];
		$lr_vote = $_POST['LR'];

		$email = $_SESSION['email'];
		$query = "UPDATE `voter` SET `GS` = '$gs_vote', `CS` = '$cs_vote', `SS` = '$ss_vote', `LR` = '$lr_vote' WHERE `email` = '$email';";
		$result = mysqli_query($conn,$query);
		
		if(!$result){
			die("something went wrong ".mysqli_error($conn));
		}
		
	}


?>

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>SC Election</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>

</head>


<body id="top">
    
    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-jump">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>


    <!-- header
    ================================================== -->
    <header class="s-header">

        <div class="row">

            <div class="header-logo">
            </div>
            
            <nav class="header-nav-wrap">
                <ul class="header-nav">
                    <li class="current"><a href="Mainpage.php">Home</a></li>
                    <li> <a  onclick="myFunction()" class="smoothscroll" class="header-nav"  href="" title="Login">Login</a></li>
                  
                    <li><a href="count_vote.php">admin</a></li>
                    
                    
 <style>                   


.dropdown {
    position: relative;
    display: inline-block;
}

.login-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.login-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown a:hover {background-color: #f1f1f1;}

.show {display: block;}
</style>

<body>

<div class="dropdown">

  <div id="myDropdown" class="login-content">           
           
      <a href="Registerlogin.php">Register</a>
    <a href="Contestantlogin.php">Contestant</a>
    <a href="voterlogin.php">Voter</a>
  </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("login-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

 
                    
                    
                    
                    <h2></h2>
                    <p><a href="file:///C:/xampp/htdocs/xampp/IP-Project-master/SC%20Election/IP-Project-v1.02-master/login1/Login-v1-master/Login_v18/index1.html?email=abelsimon30%40gmail.com&pass=asasdsad"></a></p>

</body>


                </ul>
            </nav> <!-- end header-nav-wrap -->
            
            <a class="header-menu-toggle" href="#0">
                <span class="header-menu-icon"></span>
            </a>

        </div> <!-- end row -->

    </header> <!-- end s-header -->


    <!-- home
    ================================================== -->
    <section id="home" class="s-home page-hero target-section" data-parallax="scroll" data-image-src="images/hero-bg.jpg" data-natural-width=3000 data-natural-height=2000 data-position-y=center>

        <div class="shadow-overlay"></div>

        <div class="home-content">

            <div class="row home-content__main">

                <h1>
                Welcome to the <br>
                Student Council  <br>
                Elections
                </h1>

                

      
    </section> <!-- end s-home -->


    
 <!-- Java Script
    ================================================== -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <section id="about" class="s-about target-section">

        <div class="row section-header" data-aos="fade-up">
            <div class="col-full">

<html>

<head>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body><br>
	<br>
	<div class="container">
		<div class="row">
			<form action="" method="post">

				<div class="panel-group" id="accordion">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
									General Secretary
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in">
							<div class="panel-body">
								<table class="table ">
									<thead>
										<th>Name</th>
										<th>Description</th>
										<th>Vote</th>
									</thead>
									<tbody>
										<?php 
$sql = "SELECT * FROM contestant WHERE Position='GS'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		 $name = $row['Name'];
		$position = $row['Position'];
		$msg = $row['comment'];
		echo "<tr>";
		echo "<td>$name</td>";
		echo "<td>$msg</td>";
		echo '<td><input type="radio" required name="'.$position.'" value="'.$name.'" id="'.$position.'" class="form-control"></td>';
		echo "</tr>";
		echo "<br>";
    }
} else {
    echo "0 results";
}

	
 ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
									CS
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse">
							<div class="panel-body">

								<table class="table ">
									<thead>
										<th>Name</th>
										<th>Description</th>
										<th>Vote</th>
									</thead>
									<tbody>
										<?php 
$sql = "SELECT * FROM contestant WHERE Position='CS'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	 $name = $row['Name'];
		$position = $row['Position'];
		$msg = $row['comment'];
		echo "<tr>";
		echo "<td>$name</td>";
		echo "<td>$msg</td>";
		echo '<td><input type="radio" required name="'.$position.'" value="'.$name.'" id="'.$position.'" class="form-control"></td>';
		echo "</tr>";
		echo "<br>";
    }
} else {
    echo "0 results";
}

	
 ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
									SS
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse">
							<div class="panel-body">
								<table class="table ">
									<thead>
										<th>Name</th>
										<th>Description</th>
										<th>Vote</th>
									</thead>
									<tbody>
										<?php 
$sql = "SELECT * FROM contestant WHERE Position='SS'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		 $name = $row['Name'];
		$position = $row['Position'];
		$msg = $row['comment'];
		echo "<tr>";
		echo "<td>$name</td>";
		echo "<td>$msg</td>";
		echo '<td><input type="radio" required name="'.$position.'" value="'.$name.'" id="'.$position.'" class="form-control"></td>';
		echo "</tr>";
		echo "<br>";
    }
} else {
    echo "0 results";
}

	
 ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>

					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
									LR
								</a>
							</h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse">
							<div class="panel-body">
								<table class="table ">
									<thead>
										<th>Name</th>
										<th>Description</th>
										<th>Vote</th>
									</thead>
									<tbody>
										<?php 
$sql = "SELECT * FROM contestant WHERE Position='LR'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		 $name = $row['Name'];
		$position = $row['Position'];
		$msg = $row['comment'];
		echo "<tr>";
		echo "<td>$name</td>";
		echo "<td>$msg</td>";
		echo '<td><input type="radio" required name="'.$position.'" value="'.$name.'" id="'.$position.'" class="form-control"></td>';
		echo "</tr>";
		echo "<br>";
    }
} else {
    echo "0 results";
}

	
 ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>


				<button class="btn btn-primary" name="submit">Submit</button>
            
			</form>
		</div>
	</div>



	<div class="container">



	</div> <!-- end container -->




</body>

</html>
