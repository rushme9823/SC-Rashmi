<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>SC Election</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/main.css">

    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>

</head>


<body id="top">
    
    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-jump">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>


    <!-- header
    ================================================== -->
    <header class="s-header">

        <div class="row">

            <div class="header-logo">
            </div>
            
            <nav class="header-nav-wrap">
                <ul class="header-nav">
                   <li class="current"><a href="Mainpage.php">Home</a></li>
                    <li><a class="smoothscroll"  href="#about" title="About">About</a></li>
                    <li><a class="smoothscroll"  href="#contact" title="Contact">Contact</a></li>
                   <li> <a  onclick="myFunction()" class="smoothscroll" class="header-nav"  href="" title="Login">Login</a></li>
                  <li><a href="count_vote.php">admin</a></li>
                    
                    
                    
 <style>                   


.dropdown {
    position: relative;
    display: inline-block;
}

.login-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.login-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown a:hover {background-color: #f1f1f1;}

.show {display: block;}
</style>

<body>

<div class="dropdown">

  <div id="myDropdown" class="login-content">           
           
      <a href="Registerlogin.php">Register</a>
    <a href="Contestantlogin.php">Contestant</a>
    <a href="voterlogin.php">Voter</a>
      
      
      
  </div>
</div>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("login-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

                    
                    <h2></h2>
                    <p><a href="file:///C:/xampp/htdocs/xampp/IP-Project-master/SC%20Election/IP-Project-v1.02-master/login1/Login-v1-master/Login_v18/index1.html?email=abelsimon30%40gmail.com&pass=asasdsad"></a></p>

</body>
</html>

                </ul>
            </nav> <!-- end header-nav-wrap -->
            
            <a class="header-menu-toggle" href="#0">
                <span class="header-menu-icon"></span>
            </a>

        </div> <!-- end row -->

    </header> <!-- end s-header -->


    <!-- home
    ================================================== -->
    <section id="home" class="s-home page-hero target-section" data-parallax="scroll" data-image-src="images/hero-bg.jpg" data-natural-width=3000 data-natural-height=2000 data-position-y=center>

        <div class="shadow-overlay"></div>

        <div class="home-content">

            <div class="row home-content__main">

                <h1>
                Welcome to the <br>
                Student Council  <br>
                Elections
                </h1>

                <div class="home-content__button">
                    <a href="#services" class="smoothscroll btn btn-animatedbg">
                    Eligiblity Criteria
                    </a>
                </div>
            </div>
        </div>  <!-- end home-content__main -->

        <ul class="home-social">
            <li>
                <a href="https://www.facebook.com/fcritcouncil/"><i class="fab fa-facebook-f" aria-hidden="true"></i><span>Facebook</span></a>
            </li>
            <li>
               
             <li>
                <a href="https://www.instagram.com/council.fcrit2018/?hl=en"><i class="fab fa-instagram" aria-hidden="true"></i><span>Instagram</span></a>
            </li>
           
        </ul> <!-- end home-social -->

    </section> <!-- end s-home -->


    <!-- about
    ================================================== -->
    <section id="about" class="s-about target-section">

        <div class="row section-header" data-aos="fade-up">
            <div class="col-full">
                
                <h1 class="display-1">
                About us
                </h1>
                <p class="lead">
                We here are to provide opportunities for you to organise, manage, showcase your talent at creativity in the upcoming fests of of our college i.e. Faces and Etamax.
We have started geting students who are applying for diferrent posts for which they think perfectly eligible to see the eligibilty criteria the click on the eligibity option placed above.

            </div>
        </div>

        <section id="eligibility" class="s-about target-section">
        
        
        <div class="row about-process block-1-2 block-tab-full">

            <div class="col-block item-process" data-aos="fade-up">
                <div class="item-process__header item-process__header--planning">
                    <h3>General Secretary</h3>
                </div>
                <p>

                   The whole and soul of the college. A leader whose footsteps will be followed by each and every student in our college.The one who will be capable of handling each and every situation no matter what.A general secretary in the college will be responsible for maintaining and organising all the all Student Council meetings and the fests which will be held in the college.

                   A general secretary will maintain all the permanent and temporary records of the student council and will also direct communicate with directors on behalf of the student Council. 
                </p>
            </div>
            <div class="col-block item-process" data-aos="fade-up">
                <div class="item-process__header item-process__header--branding">
                    <h3>Cultural Secretary</h3>
                </div>
                <p>
                   The Cultural Secretary shall be responsible for all intra and inter collegiate cultural events in the College.
                   To plan and schedule cultural events for the academic year.
                   To prepare budget for all cultural events and take necessary steps for its approval.
                </p> 
            </div>
            <div class="col-block item-process" data-aos="fade-up">
                <div class="item-process__header item-process__header--implementation">
                    <h3>Sports Secretary</h3>
                </div>
                <p>
                   The Sports Secretary shall be responsible for all  inter collegiate sports events in the College.
                   To plan and schedule sports events for the academic year.
                   To prepare budget for all sports events and take necessary steps for its approval.
                  
                     
                </p>
            </div>
            <div class="col-block item-process" data-aos="fade-up">
                <div class="item-process__header item-process__header--documentation">
                    <h3>Ladies Representative</h3>
                </div>
                <p>
                    The main role of a ladies representative will be to look after the problems and difficulties faced by the women in our college and to solve them. 
                </p>
            </div>

        </div>  <!-- end about-process -->

    </section> <!-- end s-about -->


    <!-- services
    ================================================== -->
    <section id="services" class="s-services target-section">

    
        <div class="row services-list block-1-3 block-m-1-2 block-tab-full">

            <div class="col-block item-service" data-aos="fade-up">
                <h4>Eligibility Criteria</h4>
                <p>
               1) The candidate should have CGPA above 6.75.
               </p>
               <p>
               2) The candidate should not be a part of any other council.
                </p>
            </div>
            
        <div class="col-block item-service" data-aos="fade-up">
                <h4>Academics</h4>
                <p>
               1) No live KT.
                </p>
                <p>
               2) Attendance should be above 75%.
                </p>
            </div>

<!--
            <div class="col-block item-service" data-aos="fade-up">
                <h4>Web Design</h4>
                <p>
                Sit ut cum molestiae. Dolore ducimus qui quasi. Fugiat consequatur sit vel illum vel et 
                a delectus. Vel sequi vitae voluptatem perspiciatis eligendi. Voluptatibus optio natus 
                asperiores est commodi amet quia architecto. Dolores necessitatibus et.
                </p>
            </div>

            <div class="col-block item-service" data-aos="fade-up">
                <h4>Product Strategy</h4>
                <p>
                Sit ut cum molestiae. Dolore ducimus qui quasi. Fugiat consequatur sit vel illum vel et 
                a delectus. Vel sequi vitae voluptatem perspiciatis eligendi. Voluptatibus optio natus 
                asperiores est commodi amet quia architecto. Dolores necessitatibus et.
                </p>
            </div>

            <div class="col-block item-service" data-aos="fade-up">
                <h4>UI/UX Design</h4>
                <p>
                Sit ut cum molestiae. Dolore ducimus qui quasi. Fugiat consequatur sit vel illum vel et 
                a delectus. Vel sequi vitae voluptatem perspiciatis eligendi. Voluptatibus optio natus 
                asperiores est commodi amet quia architecto. Dolores necessitatibus et.
                </p>
            </div>

            <div class="col-block item-service" data-aos="fade-up">
                <h4>Mobile Design</h4>
                <p>
                Sit ut cum molestiae. Dolore ducimus qui quasi. Fugiat consequatur sit vel illum vel et 
                a delectus. Vel sequi vitae voluptatem perspiciatis eligendi. Voluptatibus optio natus 
                asperiores est commodi amet quia architecto. Dolores necessitatibus et.
                </p>
            </div>
-->

        </div> <!-- end services-list -->

    </section> <!-- end s-services -->


    

             

    <!-- stats
    ================================================== -->
<!--
    <section id="stats" class="s-stats">

        <div class="row stats-block block-1-4 block-m-1-2 block-mob-full" data-aos="fade-up">
                
            <div class="col-block item-stats ">
                <div class="item-stats__count">213</div>
                <h5>Projects Completed</h5>
            </div>
            <div class="col-block item-stats">
                <div class="item-stats__count">179</div>
                <h5>Happy Clients</h5>
            </div>
            <div class="col-block item-stats">
                <div class="item-stats__count">35</div>
                <h5>Awards Received</h5>
            </div>
            <div class="col-block item-stats">
                <div class="item-stats__count">2319</div>
                <h5>Cups of Coffee</h5> 
            </div>

        </div>  /*end stats */
-->

<!--    </section>  end s-stats -->


    <!-- contact
    ================================================== -->
    <section id="contact" class="s-contact target-section">

        <div class="row section-header" data-aos="fade-up">
            <div class="col-full">
                <h3 data-num="05" class="subhead">Get In Touch</h3>
                <h1 class="display-1 display-1--light"> 
                   Have any queries? <a href="mailto:#0">fcrit.scouncil@gmail.com</a></h1>
            </div>
        </div>

        <div class="row contact-infos">

            <div class="col-five md-seven tab-full contact-address" data-aos="fade-up">
                <h4>Where to Find Us</h4>

                <p>
                  Agnel Technical Education Complex<br>
                  Sector 9-A, Vashi, Navi Mumbai,<br>
                  Maharashtra, India<br> 
                  PIN - 400703<br>

                </p>
            </div>

            <div class="col-three md-five tab-full contact-social" data-aos="fade-up">
                <h4>Follow Us</h4>

                <ul class="contact-list">
                    <li><a href="#0">Facebook</a></li>
                    <li><a href="#0">Instagram</a></li>
                </ul>
            </div>

            <div class="col-four md-six tab-full contact-number" data-aos="fade-up">
                <h4>Contact Us</h4>

                <ul class="contact-list">
                    <li><a href="mailto:#0">info@fcrit.ac.in</a></li>
                    <li><a href="tel:022-27771000">(022) 27771000</a></li>
                    <li><a href="tel:022-27660619">(022) 27660619</a></li>
                </ul>
            </div>

        </div> <!-- end contact-infos -->
    </section>

 <!-- Java Script
    ================================================== -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    </body>