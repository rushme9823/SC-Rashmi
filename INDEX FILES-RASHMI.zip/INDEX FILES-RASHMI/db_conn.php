<?php
$conn = mysqli_connect("localhost","root","","users");
if(mysqli_connect_error()){
	die("cant be connected to db");
	
	
}
else{
  echo "connected";
}

?>